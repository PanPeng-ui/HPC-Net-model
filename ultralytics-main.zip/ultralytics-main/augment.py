import os
import cv2
import numpy as np
import random
from tqdm import tqdm

# ===================== 配置 =====================
IMAGE_DIR = "datasets/train/images"
LABEL_DIR = "datasets/train/labels"
AUG_IMAGE_DIR = "datasets/train/images_aug"
AUG_LABEL_DIR = "datasets/train/labels_aug"
os.makedirs(AUG_IMAGE_DIR, exist_ok=True)
os.makedirs(AUG_LABEL_DIR, exist_ok=True)

# 方案一开关（数量适中，效果稳定）
ENABLE_FLIP_HOR = True
ENABLE_FLIP_VER = False
ENABLE_BRIGHTNESS = True
ENABLE_GAUSSIAN = True
ENABLE_SALT_PEPPER = False
ENABLE_RANDOM_CROP = True

# =================================================

def load_yolo_label(label_path):
    with open(label_path, 'r') as f:
        lines = f.readlines()
    return [line.strip().split() for line in lines]

def save_yolo_label(label_path, labels):
    with open(label_path, 'w') as f:
        for label in labels:
            f.write(' '.join(label) + '\n')

def augment():
    print("开始检查路径...")
    print("图片路径存在：", os.path.exists(IMAGE_DIR))
    print("标签路径存在：", os.path.exists(LABEL_DIR))
    if not os.path.exists(IMAGE_DIR) or not os.path.exists(LABEL_DIR):
        print("❌ 路径错误，请检查 IMAGE_DIR 和 LABEL_DIR！")
        return

    img_files = [f for f in os.listdir(IMAGE_DIR) if f.endswith(('jpg', 'png', 'jpeg'))]
    print(f"找到 {len(img_files)} 张图片")
    if len(img_files) == 0:
        print("❌ 图片文件夹为空！")
        return

    for img_file in tqdm(img_files):
        img_path = os.path.join(IMAGE_DIR, img_file)
        lab_path = os.path.join(LABEL_DIR, os.path.splitext(img_file)[0] + '.txt')

        if not os.path.exists(lab_path):
            print(f"⚠️  未找到标签文件：{lab_path}，跳过该图片")
            continue

        img = cv2.imread(img_path)
        h, w = img.shape[:2]
        labels = load_yolo_label(lab_path)

        # 1. 保存原图
        cv2.imwrite(os.path.join(AUG_IMAGE_DIR, img_file), img)
        save_yolo_label(os.path.join(AUG_LABEL_DIR, os.path.splitext(img_file)[0] + '.txt'), labels)

        # 2. 水平翻转
        if ENABLE_FLIP_HOR:
            img_flip = cv2.flip(img, 1)
            new_labs = []
            for lab in labels:
                cls, x, y, ww, hh = lab
                x = 1.0 - float(x)
                new_labs.append([cls, f"{x:.6f}", y, ww, hh])
            cv2.imwrite(os.path.join(AUG_IMAGE_DIR, f"flip_h_{img_file}"), img_flip)
            save_yolo_label(os.path.join(AUG_LABEL_DIR, f"flip_h_{os.path.splitext(img_file)[0]}.txt"), new_labs)

        # 3. 亮度变化
        if ENABLE_BRIGHTNESS:
            val = random.uniform(0.5, 1.5)
            img_bright = cv2.convertScaleAbs(img, alpha=val, beta=0)
            cv2.imwrite(os.path.join(AUG_IMAGE_DIR, f"bright_{img_file}"), img_bright)
            save_yolo_label(os.path.join(AUG_LABEL_DIR, f"bright_{os.path.splitext(img_file)[0]}.txt"), labels)

        # 4. 高斯噪声
        if ENABLE_GAUSSIAN:
            noise = np.random.normal(0, 10, img.shape).astype(np.float32)
            img_noisy = cv2.add(img.astype(np.float32), noise).clip(0, 255).astype(np.uint8)
            cv2.imwrite(os.path.join(AUG_IMAGE_DIR, f"gauss_{img_file}"), img_noisy)
            save_yolo_label(os.path.join(AUG_LABEL_DIR, f"gauss_{os.path.splitext(img_file)[0]}.txt"), labels)

        # 5. 随机裁剪
        if ENABLE_RANDOM_CROP:
            crop_h, crop_w = int(h * 0.8), int(w * 0.8)
            top = random.randint(0, h - crop_h)
            left = random.randint(0, w - crop_w)
            crop = img[top:top + crop_h, left:left + crop_w]
            new_labs = []
            for lab in labels:
                cls, x, y, ww, hh = lab
                x, y, ww, hh = float(x), float(y), float(ww), float(hh)
                x1 = (x - ww / 2) * w
                y1 = (y - hh / 2) * h
                x2 = (x + ww / 2) * w
                y2 = (y + hh / 2) * h
                if x2 < left or x1 > left + crop_w or y2 < top or y1 > top + crop_h:
                    continue
                nx = (x1 - left + (x2 - x1) / 2) / crop_w
                ny = (y1 - top + (y2 - y1) / 2) / crop_h
                nww = ww * w / crop_w
                nhh = hh * h / crop_h
                new_labs.append([cls, f"{nx:.6f}", f"{ny:.6f}", f"{nww:.6f}", f"{nhh:.6f}"])
            if new_labs:
                cv2.imwrite(os.path.join(AUG_IMAGE_DIR, f"crop_{img_file}"), crop)
                save_yolo_label(os.path.join(AUG_LABEL_DIR, f"crop_{os.path.splitext(img_file)[0]}.txt"), new_labs)

    print("✅ 数据集扩充完成！")

if __name__ == "__main__":
    augment()