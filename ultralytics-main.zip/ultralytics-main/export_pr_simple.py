from ultralytics import YOLO
import pandas as pd

# --------------------------
# 改成你自己的路径
# --------------------------
model_path = "runs/detect/train9/weights/best.pt"
data_path = "data.yaml"

if __name__ == "__main__":
    # 加载模型并跑验证
    model = YOLO(model_path)
    metrics = model.val(data=data_path, plots=True)

    # 直接从 metrics 里拿所有类别的 P/R 数据
    # 这两个就是你画 PR 曲线要用的数组
    recall = metrics.box.recall
    precision = metrics.box.precision

    # 导出成 Origin 能直接用的 CSV
    df = pd.DataFrame({
        "Recall": recall,
        "Precision": precision
    })
    df.to_csv("pr_curve_data.csv", index=False)

    print("✅ pr_curve_data.csv 已生成，和脚本在同一目录！")