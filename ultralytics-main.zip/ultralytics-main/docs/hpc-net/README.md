# HPC-Net

HPC-Net is a YOLOv8s-based steel-surface defect detector. Load
`ultralytics/cfg/models/v8/hpc-net.yaml` to use the default `s` scale.

Implemented components:
- P2 to P5 four-scale detection heads.
- CADBAM attention on P2, P3, P4 and P5 neck outputs.
- Optional Inner-EIoU localization loss with R=1.2 auxiliary boxes and independent width and height constraints.

Train from the repository root after activating the yolov8 environment.
The training command should insert the repository path before importing ultralytics so this checkout is used.
